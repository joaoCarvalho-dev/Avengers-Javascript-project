/*
Javascript function that reacts to user input on the range input
with the id page_rating, showing the user four different responses
*/
function rate() {
    
var x = document.getElementById("page_rating").value;
    
if (x>=80) {
    document.getElementById("opinion").innerHTML = "Amazing page";
}
    
else if (x>=60) {
    document.getElementById("opinion").innerHTML = "Very Good page";
}
    
else if (x>=40) {
    document.getElementById("opinion").innerHTML = "OK page";
}
    
else {
    document.getElementById("opinion").innerHTML = "Bad page";
}
    
}


/*
Javascript function that when the user clicks on the
button with the id movie_links it shows two additional movie links
*/
function show_hide() {
    var x = document.getElementById("movie_links");
    if (x.style.display === "none") {
        x.style.display = "block";
        document.getElementById("show_links").innerHTML = "Hide Movie Links";
    } else {
        x.style.display = "none";
        document.getElementById("show_links").innerHTML = "Show Movie Links";
    }
}


/*
Javascript function that that when the user clicks on the
button with the id choose_hero, generates a random number and
according to number generated it displays a Justice League Hero
with some biographic information
*/
function show_hero() {
    var superHero = Math.floor(Math.random() * 6) + 1;
    switch(superHero) {
    case 1:
        document.getElementById("Alias").innerHTML = "Clark Kent";
        document.getElementById("Powers").innerHTML = "super strength, flight, invulnerability, super speed, heat vision, freeze breath, x-ray vision, superhuman hearing, healing factor";
        document.getElementById("Base_Operations").innerHTML = "Metropolis";
        document.getElementById("Real_Name").innerHTML = "Kal-El, Clark Joseph Kent";
        document.getElementById("Occupation").innerHTML = "Reporter";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Superman</h2>";
        document.getElementById("logo").src = "Logo/logo_superman.jpg";
        document.getElementById("logo").title.alt = "Superman Logo";
        document.getElementById("logo").alt = "Superman Logo";
        document.getElementById("logo_caption").innerHTML = "Superman Logo";
        break;
    case 2:
        document.getElementById("Alias").innerHTML = "Wonder Woman";
        document.getElementById("Powers").innerHTML = "super strength, invulnerability, flight, combat skill, combat strategy, superhuman agility, healing factor, magic weaponry";
        document.getElementById("Base_Operations").innerHTML = "Unknown";
        document.getElementById("Real_Name").innerHTML = "Diana";
        document.getElementById("Occupation").innerHTML = "Amazon Princess";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Wonder Woman</h2>";
        document.getElementById("logo").src = "Logo/logo_wonderwoman.jpg";
        document.getElementById("logo").title.alt = "Wonder Woman Logo";
        document.getElementById("logo").alt = "Wonder Woman Logo";
        document.getElementById("logo_caption").innerHTML = "Superman Logo";
        break;
    case 3:
        document.getElementById("Alias").innerHTML = "Cyborg";
        document.getElementById("Powers").innerHTML = "super strength, advanced technology, instant weaponry, genius-level intellect, control over technology, computer hacking, durability, teleportation";
        document.getElementById("Base_Operations").innerHTML = "Detroit";
        document.getElementById("Real_Name").innerHTML = "Victor \"Vic\" Stone";
        document.getElementById("Occupation").innerHTML = "Former student";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Cyborg</h2>";
        document.getElementById("logo").src = "Logo/logo_cyborg.jpg";
        document.getElementById("logo").title = "Cyborg Logo";
        document.getElementById("logo").alt = "Cyborg Logo";
        document.getElementById("logo_caption").innerHTML = "Cyborg Logo";
        break;
    case 4:
        document.getElementById("Alias").innerHTML = "Dark Knight, Caped Crusader, Matches Malone";
        document.getElementById("Powers").innerHTML = "exceptional martial artist, combat strategy, inexhaustible wealth, brilliant deductive skill, advanced technology";
        document.getElementById("Base_Operations").innerHTML = "Gotham City";
        document.getElementById("Real_Name").innerHTML = "Bruce Wayne";
        document.getElementById("Occupation").innerHTML = "CEO of Wayne Enterprises";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Batman</h2>";
        document.getElementById("logo").src = "Logo/logo_batman.jpg";
        document.getElementById("logo").title = "Batman Logo";
        document.getElementById("logo").alt = "Batman Logo";
        document.getElementById("logo_caption").innerHTML = "Batman Logo";
        break;
    case 5:
        document.getElementById("Alias").innerHTML = "Scarlet Speedster, The Fastest Man Alive";
        document.getElementById("Powers").innerHTML = "super speed, intangibility, superhuman agility";
        document.getElementById("Base_Operations").innerHTML = "Central City";
        document.getElementById("Real_Name").innerHTML = "Barry Allen";
        document.getElementById("Occupation").innerHTML = "Forensic scientist";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Superman</h2>";
        document.getElementById("logo").src = "Logo/logo_flash.jpg";
        document.getElementById("logo").title = "Flash Logo";
        document.getElementById("logo").alt = "Flash Logo";
        document.getElementById("logo_caption").innerHTML = "Flash Logo";
        break;
    case 6:
        document.getElementById("Alias").innerHTML = "Scarlet Speedster, The Fastest Man Alive";
        document.getElementById("Powers").innerHTML = "super strength, durability, control over sea life, exceptional swimming ability, ability to breathe underwater";
        document.getElementById("Base_Operations").innerHTML = "Atlantis City";
        document.getElementById("Real_Name").innerHTML = "Arthur Curry";
        document.getElementById("Occupation").innerHTML = "King of Atlantis";
        document.getElementById("Alignment").innerHTML = "Hero";
        document.getElementById("super_hero_title").innerHTML = "<h2>Aquaman</h2>";
        document.getElementById("logo").src = "Logo/logo_aquaman.jpg";
        document.getElementById("logo").title = "Aquaman Logo";
        document.getElementById("logo").alt = "Aquaman Logo";
        document.getElementById("logo_caption").innerHTML = "Aquaman Logo";
}
}

